/*Use an alert command to show Javascript is connected*/
alert("Congrats the Javascript file is connected correctly!");


//Write out one line of text in the console
console.log("I can display text in the Console!");
